// ==UserScript==
// @name        reauth telegram.org
// @namespace   Violentmonkey Scripts
// @match       https://web.telegram.org/a/*
// @grant       none
// @version     1.0
// @author      -
// @description 9/9/2022, 8:43:29 PM
// ==/UserScript==
function notifyMe() {
  var notification = new Notification('Reauthenticate', {
   icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Gmail_Icon_%282013-2020%29.svg/512px-Gmail_Icon_%282013-2020%29.svg.png',
   body: 'reauth gmail',
  });
  notification.onclick = function() {
   window.open('https://web.telegram.org/a/');
  };
};
setInterval(() => {document.querySelectorAll("div.subtitle").forEach(x=>{if(x.textContent.includes("google")){notifyMe()}})}, 5000)
