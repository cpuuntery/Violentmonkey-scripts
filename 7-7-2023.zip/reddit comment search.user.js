// ==UserScript==
// @name        reddit comment search
// @namespace   Violentmonkey Scripts
// @match       https://www.reddit.com/*
// @grant       none
// @version     1.0
// @author      -
// @description 1/26/2023, 9:06:23 AM
// @run-at       document-start
// ==/UserScript==
document.cookie = "token_v2=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2NzQ4MDk2MjksInN1YiI6Ii1BU085WXlFX00xaF9pdkx5TDBQd0QyNzk3SU5QUUEiLCJsb2dnZWRJbiI6ZmFsc2UsInNjb3BlcyI6WyIqIiwiZW1haWwiLCJwaWkiXX0.qYZfwYGST9vUceg1hGENmdUVgC7WfqCukf6MvOpNMig"
document.cookie = "loid=0000000000vo1qmgjw.2.1674462609000.Z0FBQUFBQmp6a1dSYVRwbGNsbVBzTFNnZzJkRE1jM19mak5ZLUNNX3c5VG94YzBNWmFtOWVkcnNWSERNTVNtOEVCYWdJTmdkekdwTU9EV0tPNzR5aVJlZGZuVmc1LXFmenBMc1RoVHdnM2JqUWhuRDE4T0hmWTBHbUlSWWlaclNYRmhsYjJ3V0pBc2E"
document.cookie = "edgebucket=q4ZWURdlzxJhstsDWI"
document.cookie = "session_tracker=qbqglojcmldpkmnkag.0.1674723332730.Z0FBQUFBQmowa0FFUUdXc0lJSmIxalRKcW5uMnVnRWpYVklkbGZlby15ekxqUUJ3SlBkNnRPT09MZzJhQV9jV2VQUDgtX1BoM0J1U0R5TDNuNTRSeVBXUU1wMW5lWHFoUU5CdkRYal9wVDVTbmZFekhVdUJCSjJOUHlzcFNfMkxOVGVJSUJBX184WGI"
document.cookie = "csv=2"