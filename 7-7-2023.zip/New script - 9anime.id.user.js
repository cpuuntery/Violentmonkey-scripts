// ==UserScript==
// @name        New script - 9anime.id
// @namespace   Violentmonkey Scripts
// @include       https:\/\/9anime.*
// @grant       none
// @version     1.0
// @author      -
// @description 9/4/2022, 10:02:49 AM
// ==/UserScript==
if(localStorage["prefered_server_type"]=='"sub"'||localStorage["prefered_server_type"] == undefined)
{
localStorage["prefered_server_type"] = '"dub"'
localStorage["prefered_source_type"] = "dub"
localStorage["title_lang"] = "en"
  location.reload()
}