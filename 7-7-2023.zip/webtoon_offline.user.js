// ==UserScript==
// @name        webtoon_offline
// @namespace   Violentmonkey Scripts
// @match       file:///*/your_thron.html
// @grant       none
// @version     1.0
// @author      -
// @description 2/25/2023, 4:09:17 PM
// ==/UserScript==
setTimeout(() => document.querySelectorAll("img").forEach(x => {if(x.height == '16'){x.remove()}}), 5000)