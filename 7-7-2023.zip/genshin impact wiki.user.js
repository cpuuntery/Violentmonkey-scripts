// ==UserScript==
// @name        genshin impact wiki
// @namespace   Violentmonkey Scripts
// @match       https://genshin-impact.fandom.com/wiki/World_Quest*
// @grant       none
// @version     1.0
// @author      -
// @description 9/15/2022, 12:31:53 AM
// ==/UserScript==
setTimeout(() => {$("li:contains('Woodland Encounter')").remove()
$("li:contains('The Children of Vimara Village')").remove()
$("li:contains('Into the Woods')").remove()
$("li:contains('The Lost Child')").remove()
$("li:contains('The World of Aranara')").remove()
$("li:contains('Children of the Forest')").remove()
$("li:contains('Encounter in the Woods')").remove()
$("li:contains('The Rhythm that Leads to the Gloomy Path')").remove()
$("li:contains('The Rhythm that Nurtures the Sprout')").remove()
$("li:contains('The Rhythm that Reveals the Beastly Trail')").remove()
$("li:contains('For A Better Reunion')").remove()
$("li:contains('Festival Utsava')").remove()
$("li:contains('For Fruits, Seeds, and Trees')").remove()
$("li:contains('For the Children of the Past')").remove()
$("li:contains('For All Children Who Long for Life')").remove()
$("li:contains('A Delicacy for Nara')").remove()
$("li:contains('A Prayer for Rain on the Fecund Land')").remove()
$("li:contains('Cooking, a Pleasant Memory')").remove()
$("li:contains('Cooking, the Aroma of Homecoming')").remove()
$("li:contains('Cooking, the Beauty of Sharing')").remove()
$("li:contains('Cooking, the Flavor of Nature')").remove()
$("li:contains('Delicious Riddle')").remove()
$("li:contains('Trees and Dreams')").remove()
$("li:contains('Until Vana is Healed')").remove()
$("li:contains('Varuna Gatha')").remove()
$("li:contains('Vimana Agama: Dev Delver Chapter')").remove()
$("li:contains('Vimana Agama: First Chapter')").remove()
$("li:contains('Jazari')").remove()
$("li:contains('Memory of Stone')").remove()
$("li:contains('Royinjan')").remove()
$("li:contains('Slumbering Roots')").remove()
$("li:contains('Starry Night Chapter')").remove()
$("li:contains('Taste of Happiness')").remove()
$("li:contains('The Final Chapter')").remove()
$("li:contains('Garden Fairies')").remove()
$("li:contains('Irate Iron Chunk')").remove()
$("li:contains('Quest_to_be_removed')").remove()
$("li:contains('Sprouting Seedlings')").remove()
$("li:contains('Rishboland Tiger, roaaar')").remove()}, 1000)