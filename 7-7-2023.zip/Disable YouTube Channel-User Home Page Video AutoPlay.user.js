// ==UserScript==
// @name         Disable YouTube Channel/User Home Page Video AutoPlay
// @namespace    DisableYouTubeChannelUserHomePageVideoAutoPlay
// @version      2.0.16
// @license      GNU AGPLv3
// @author       jcunews
// @description  Disable the video autoplay at YouTube channel/user home page
// @website      https://greasyfork.org/en/users/85671-jcunews
// @match        https://www.youtube.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(() => {
  let xo = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(mtd, url) {
    this.url_dyuhpv = url;
    return xo.apply(this, arguments)
  };
  let xs = XMLHttpRequest.prototype.send, rx = /:\/\/[^\/]+\/(c(hannel)?|u(ser)?)\/[^\/]+(\/(about|featured)?)?(\?|$)|\/@(.+)/, blk;
  XMLHttpRequest.prototype.send = function(dat) {
    if (/player\?key=/.test(this.url_dyuhpv) && dat && dat.toUpperCase) {
      let z, o;
      try {
        if (
          (o = (o = JSON.parse(dat)).context.client) && (rx.test(o.originalUrl) | ((o = o.mainAppWebInfo) && rx.test(o.graftUrl)))
        ) blk = true
      } catch(z) {}
    }
    return xs.apply(this, arguments)
  };
  let mp = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function() {
    if (blk) throw blk = false;
    return mp.apply(this, arguments)
  };
})();
