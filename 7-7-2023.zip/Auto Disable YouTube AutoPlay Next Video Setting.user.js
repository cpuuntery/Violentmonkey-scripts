// ==UserScript==
// @name         Auto Disable YouTube AutoPlay Next Video Setting
// @namespace    AutoDisableYouTubeAutoPlayNextVideoSetting
// @version      1.0.5
// @license      GNU AGPLv3
// @author       jcunews
// @description  Auto disable YouTube's AutoPlay Next Video setting at top sidebar of video page
// @match        https://www.youtube.com/*
// @grant        none
// ==/UserScript==

setInterval(eleCheck => {
  if (
    ((eleCheck = document.querySelector("#autoplay-checkbox,#improved-toggle.ytd-compact-autoplay-renderer,#toggle.ytd-compact-autoplay-renderer")) &&
      eleCheck.attributes["checked"]) ||
    (eleCheck = document.querySelector('ytd-watch-flexy:not([hidden]) .ytp-autonav-toggle-button[aria-checked="true"]'))
  ) eleCheck.click();
}, 5000);
