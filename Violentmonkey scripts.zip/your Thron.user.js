// ==UserScript==
// @name        your Thron
// @namespace   Violentmonkey Scripts
// @match       file:///C:/Users/Yousif/Videos/your*
// @grant       none
// @version     1.0
// @author      -
// @description 11/16/2020, 7:51:21 AM
// ==/UserScript==
var data = JSON.parse(prompt('Enter the json file here. But before that did you change the cookie'));
data["message"]["result"]["episodeInfo"]["imageInfo"].forEach(function(obj) {
  var img = new Image();
  img.src = obj.url;
  document.getElementById("img-container").appendChild(img);
});