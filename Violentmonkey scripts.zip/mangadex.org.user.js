// ==UserScript==
// @name        mangadex.org
// @namespace   Violentmonkey Scripts
// @match       https://mangadex.org/*
// @grant       none
// @version     1.0
// @author      -
// @description 10/30/2020, 10:18:12 PM
// ==/UserScript==
localStorage["md"] = "{\"readerMenu\":{\"readStyle\":0,\"viewStyle\":2,\"fitStyle\":0,\"stretchStyle\":3,\"headerStyle\":0,\"progressBarDirection\":1,\"doAutoAdvance\":true,\"historyMode\":1,\"limitMaxWidth\":false,\"limitMaxHeight\":false,\"maxWidth\":-1,\"maxHeight\":-1,\"keys\":{\"toggleMenu\":[\"KeyM\",null],\"pageForward\":[\"ArrowRight\",null],\"pageBackward\":[\"ArrowLeft\",null],\"chapterForward\":[\"Period\",null],\"chapterBackward\":[\"Comma\",null],\"immersiveMode\":[\"KeyF\",null],\"offsetSpread\":[\"KeyO\",null]},\"lock\":{\"width\":true,\"height\":false,\"contain\":true,\"none\":false},\"lockOffset\":0,\"longStripMargin\":0,\"offsetDoubles\":{},\"hasImmersiveBefore\":false,\"backgroundColor\":\"transparent\"},\"drawer\":{},\"userPreferences\":{\"filteredLanguages\":[\"en\"],\"paginationCount\":100,\"initialLoadCount\":50,\"subsequentLoadCount\":50,\"showSafe\":true,\"showErotic\":false,\"showSuggestive\":false,\"showHentai\":false,\"isDark\":false,\"mdahPort443\":false,\"dataSaver\":false}}"