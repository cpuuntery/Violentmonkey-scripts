// ==UserScript==
// @name        pixiv.net jquery
// @namespace   Violentmonkey Scripts
// @match       https://www.pixiv.net/*
// @grant       none
// @version     1.0
// @author      -
// @description 8/4/2021, 11:19:05 PM
// @require https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js
// ==/UserScript==

