// ==UserScript==
// @name        youtube-big-buttons-destroyer
// @namespace   Violentmonkey Scripts
// @match       https://www.youtube.com/watch
// @grant       none
// @version     1.0
// @author      -
// @description 8/20/2020, 2:36:08 AM
// ==/UserScript==
document.querySelector('.html5-video-player').classList.remove('ytp-exp-bigger-button-like-mobile')