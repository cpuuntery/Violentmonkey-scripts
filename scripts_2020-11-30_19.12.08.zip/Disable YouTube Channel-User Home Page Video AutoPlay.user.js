// ==UserScript==
// @name        Disable YouTube Channel/User Home Page Video AutoPlay
// @namespace   DisableYouTubeChannelUserHomePageVideoAutoPlay
// @version     1.0.11
// @license     GNU AGPLv3
// @author      jcunews
// @description Disable the video autoplay at YouTube channel/user home page
// @match       https://www.youtube.com/*
// @grant       none
// @run-at      document-start
// ==/UserScript==

(function(listen, shldAutoplay, pmShldAutoplay, updPlayer, create, c4player, prevConfig) {
  function modConfig(config, a) {
    if (config) {
      if (config.args) {
        config.args.autoplay = "0";
        config.args.external_play_video = "0";
        delete config.args.el;
        a = config.args.raw_player_response || JSON.parse(config.args.player_response);
        a.playerConfig = config.playerConfig || {};
        a.playerConfig.playbackStartConfig = a.playerConfig.playbackStartConfig || {};
        a.playerConfig.playbackStartConfig.startPaused = true;
        if (!config.args.raw_player_response) config.args.player_response = JSON.stringify(a);
      }
    }
  }
  (function waitNav(pm) {
    if (!listen && document.body) {
      if (!document.body.id) { //new youtube
        if (window.nav) {
          listen = (pm = document.querySelector("yt-player-manager")).constructor.prototype;
          shldAutoplay = listen.shouldAutoplay_;
          listen.shouldAutoplay_ = function(config) {
            modConfig(config);
            return shldAutoplay.apply(this, arguments);
          };
          pmShldAutoplay = pm.shouldAutoplay_;
          pm.shouldAutoplay_ = function(config) {
            modConfig(config);
            return pmShldAutoplay.apply(this, arguments);
          };
          updPlayer = nav.updatePlayer_;
          nav.updatePlayer_ = function(config) {
            modConfig(config);
            return updPlayer.apply(this, arguments);
          };
          return;
        }
      } else { //old youtube
        listen = 1;
        addEventListener("spfpartprocess", function(ev) { //old youtube
          if ((ev = ev.detail) && (ev = ev.part) && (ev = ev.data) && (ev = ev.swfcfg) &&
            (ev = ev.args) && (/^\/(channel|user)\//).test(ev.loaderUrl)) {
            ev.autoplay = "0";
          }
        });
        return;
      }
    }
    setTimeout(waitNav, 20);
  })();
  function waitYpac() {
    if (document.body) {
      if (document.body.id) return; //old youtube
      if (window.yt && yt.player && yt.player.Application && yt.player.Application.create && !create) {
        create = yt.player.Application.create;
        yt.player.Application.create = function(player, config) {
          if (config.attrs && (config.attrs.id === "c4-player")) {
            modConfig(config);
            (res = create.apply(this, arguments)).stopVideo();
            return res;
          } else return create.apply(this, arguments);
        };
        removeEventListener(et, waitYpac);
        return;
      }
    }
    if (et === "message") postMessage();
  }
  addEventListener(et = (window.InstallTrigger ? "beforescriptexecute" : "message"), waitYpac);
  waitYpac();
})();
