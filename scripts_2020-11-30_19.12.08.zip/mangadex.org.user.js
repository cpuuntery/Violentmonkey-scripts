// ==UserScript==
// @name        mangadex.org
// @namespace   Violentmonkey Scripts
// @match       https://mangadex.org/*
// @grant       none
// @version     1.0
// @author      -
// @description 10/30/2020, 10:18:12 PM
// ==/UserScript==
localStorage["reader.hidePagebar"] = "1";
localStorage["reader.renderingMode"] = "3";

