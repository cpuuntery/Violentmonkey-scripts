// ==UserScript==
// @name        New script - redditsharp-b7de3.firebaseapp.com
// @namespace   Violentmonkey Scripts
// @match       https://redditsharp-b7de3.firebaseapp.com/r/*
// @grant       none
// @version     1.0
// @author      -
// @description 8/16/2022, 1:11:14 AM
// ==/UserScript==
localStorage["filterMode"] = "month";
localStorage["sortMode"] = "top";