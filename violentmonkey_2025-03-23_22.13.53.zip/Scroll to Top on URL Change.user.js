// ==UserScript==
// @name         Scroll to Top on URL Change
// @match        https://mangadex.org/chapter/*
// @version      1.1
// @description  Scroll up when the URL changes in a Single Page Web App, ignoring trailing segments
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to scroll to the top of the page
    function scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Function to normalize the URL by removing the last slash and anything after it
    function normalizeUrl(url) {
        return url.replace(/\/[^\/]*$/, ''); // Remove the last forward slash and anything after it
    }

    // Function to handle URL changes
    function handleUrlChange() {
        scrollToTop();
    }

    // Store the normalized current URL
    let currentUrl = normalizeUrl(location.href);

    // Set up a MutationObserver to detect changes in the URL
    const observer = new MutationObserver(() => {
        const normalizedHref = normalizeUrl(location.href);
        if (normalizedHref !== currentUrl) {
            currentUrl = normalizedHref;
            handleUrlChange();
        }
    });

    // Start observing changes in the document
    observer.observe(document, { childList: true, subtree: true });

    // Fallback for modern pushState/popState changes
    window.addEventListener('popstate', () => {
        const normalizedHref = normalizeUrl(location.href);
        if (normalizedHref !== currentUrl) {
            currentUrl = normalizedHref;
            handleUrlChange();
        }
    });

})();
