// ==UserScript==
// @name        1999 wiki eng
// @namespace   Violentmonkey Scripts
// @match       https://res1999.huijiwiki.com/wiki/*
// @run-at          document-end
// @version     1.0
// @author      -
// @description 16/07/2024, 04:02:15
// ==/UserScript==


setTimeout(() => {
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/生命/g, "HP")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/攻击/g, "ATK")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/暴击率/g, "Crit Rate")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/术法威力/g, "Inc Might")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/仪式威力/g, "Ult Might")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/穿透率/g, "Penetration")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/暴击创伤/g, "Crit DMG")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/暴击防御/g, "Crit DEF")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/现实防御/g, "Reality DEF")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/精神防御/g, "Mental DEF")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/抗暴率/g, "Crit R Rate")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/创伤加成/g, "DMG Bonus")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/受创减免/g, "DMG Taken Reduction")})
$(document.body).find("*").contents().filter(function() {return this.nodeType === 3}).each(function() {this.nodeValue = this.nodeValue.replace(/受创回复/g, "DMG Heal")})
}, 1000);







