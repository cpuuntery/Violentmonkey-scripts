// ==UserScript==
// @name        comick.io
// @namespace   Violentmonkey Scripts
// @match       https://comick.io/*
// @grant       none
// @version     1.0
// @author      -
// @description 04/09/2024, 07:19:24
// ==/UserScript==
localStorage["reader_minimize_sidebar"] = "true"
localStorage["REACT_QUERY_OFFLINE_CACHE"] = '{"buster":"3","timestamp":1726891522125,"clientState":{"mutations":[],"queries":[{"state":{"data":{"info":{"accept_mature_content":false,"reader_mode":"scroll","reader_mode_sm":"scroll","reader_remove_margin":false,"reader_remove_margin_sm":false,"reader_direction":"right","language":["en"]}},"dataUpdateCount":3,"dataUpdatedAt":1726891415653,"error":null,"errorUpdateCount":0,"errorUpdatedAt":0,"fetchFailureCount":0,"fetchFailureReason":null,"fetchMeta":null,"isInvalidated":false,"status":"success","fetchStatus":"idle"},"queryKey":["user"],"queryHash":"[\\"user\\"]"}]}}'