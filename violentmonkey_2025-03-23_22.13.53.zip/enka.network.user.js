// ==UserScript==
// @name        enka.network
// @namespace   Violentmonkey Scripts
// @match       https://enka.network/u/*
// @grant       none
// @version     1.0
// @author      -
// @description 2/10/2023, 7:59:34 PM
// ==/UserScript==
setTimeout(() => {
	elm = document.createElement('textarea');
	elm.setAttribute("id", "output");
	elm1 = document.createElement('textarea');
	elm1.setAttribute("id", "output1");
	div = document.createElement('div');
	div.setAttribute("id", "parent");
	document.querySelector('body').prepend(div)
	document.getElementById('parent').appendChild(elm)
	document.getElementById('parent').appendChild(elm1)
	document.querySelector("#parent").style.display = 'flex'
	document.querySelector("#output").style.height = '55px'
	document.querySelector("#output1").style.height = '55px'
	document.querySelector("#output1").style.width = '1500px'
	document.querySelector("#output").style.fontFamily = 'monospace'
	document.querySelector("#output1").style.fontFamily = 'monospace'
	setInterval(() => {
		if (localStorage["uid"] == window.location.href.match(/\d+/g)[0]) {} else {
			localStorage["uid"] = window.location.href.match(/\d+/g)[0]
			uid = window.location.href.match(/\d+/g)[0]
			async function getdata() {
				output = await fetch(`https://enka.network/api/uid/${uid}`).then(response => response.json())
				Abyss_Stars = output["playerInfo"]["towerStarIndex"]
				Theater_Stars = output["playerInfo"]["theaterStarIndex"]
        Theater_Act = output["playerInfo"]["theaterActIndex"]
				document.querySelector("#output").textContent = ''
        document.querySelector("#output").textContent += `Theater Act ${Theater_Act}\n`
        document.querySelector("#output").textContent += `Theater Stars ${Theater_Stars}\n`
				document.querySelector("#output").textContent += `Abyss Stars ${Abyss_Stars}`



				function findAllByKey(obj, keyToFind) {
					return Object.entries(obj)
						.reduce((acc, [key, value]) => (key === keyToFind) ?
							acc.concat(value) :
							(typeof value === 'object' && value) ?
							acc.concat(findAllByKey(value, keyToFind)) :
							acc, []) || [];
				}

				function intersectKeys(first, ...rest) {
					restKeys = rest.map(o => Object.keys(o));
					return Object.fromEntries(Object.entries(first).filter(entry => restKeys.every(rk => rk.includes(entry[0]))));
				}
				usernamecardsarray = []
				usernamecards = {};
				if (!(output["playerInfo"]["showNameCardIdList"] === undefined)) {
					usernamecardsarray.push(...output["playerInfo"]["showNameCardIdList"])
				}
				usernamecardsarray.forEach(element => {
					usernamecards[element] = ''
				})
				namecards = await fetch('https://raw.githubusercontent.com/EnkaNetwork/API-docs/master/store/namecards.json').then(response => response.json())
				namecardlist = intersectKeys(namecards, usernamecards)
				document.querySelector("#output1").textContent = ''
				findAllByKey(namecardlist, 'icon').forEach(x => {
					x.match(/(?<=UI_NameCardPic_).*?(?=_P)/gmi).forEach(x => document.querySelector("#output1").textContent += x + '     ')
				})
				profileamecardarray = []
				profileamecard = {}
				profileamecardarray = output["playerInfo"]["nameCardId"]
				profileamecard[profileamecardarray] = ''
				namecardlist = intersectKeys(namecards, profileamecard)
				findAllByKey(namecardlist, 'icon').forEach(x => {
					x.match(/(?<=UI_NameCardPic_).*?(?=_P)/gmi).forEach(x => document.querySelector("#output1").textContent += `\n\nProfile Name Card     ${x}`)
				})
			}
			getdata()
		}
	}, 1000)
}, 1000);