// ==UserScript==
// @name        thwiki.cc no vocal
// @namespace   Violentmonkey Scripts
// @match       https://thwiki.cc/*
// @grant       none
// @version     1.0
// @author      -
// @description 2/4/2021, 8:24:44 PM
// ==/UserScript==
function exc() {$(".infoRD").siblings().siblings().remove()
$("tr:contains('Vocal')").next().next().next().find(".label").remove()
$("tr:contains('Vocal')").next().next().next().find(".left").remove()
$("tr:contains('Vocal')").next().next().next().find(".text").remove()
$("tr:contains('Vocal')").next().next().remove()
$("tr:contains('Vocal')").next().remove()
$("tr:contains('Vocal')").prev().remove()
$("tr:contains('Vocal')").remove()}
setTimeout(exc, 1000);