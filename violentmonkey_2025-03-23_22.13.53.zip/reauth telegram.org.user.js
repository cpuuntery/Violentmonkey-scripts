// ==UserScript==
// @name        reauth telegram.org
// @namespace   Violentmonkey Scripts
// @match       https://web.telegram.org/k/*
// @grant       none
// @version     1.0
// @author      -
// @description 9/9/2022, 8:43:29 PM
// ==/UserScript==
function notifyMe() {
  var notification = new Notification('Reauthenticate', {
   body: 'reauth gmail',
  });
  notification.onclick = function() {
   window.open('https://web.telegram.org/a/');
  };
};
setInterval(() => {document.querySelectorAll("div.row-subtitle").forEach(x=>{if(x.textContent.includes("google")){notifyMe()}})}, 5000)
