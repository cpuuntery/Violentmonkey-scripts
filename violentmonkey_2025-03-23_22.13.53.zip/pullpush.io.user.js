// ==UserScript==
// @name        pullpush.io
// @namespace   Violentmonkey Scripts
// @match       https://search.pullpush.io/*
// @grant       none
// @version     1.0
// @author      -
// @description 7/21/2023, 5:08:58 AM
// ==/UserScript==
setInterval(() => document.querySelector("head > title").textContent = `r/${document.querySelector("#subreddit").value + ' ' + document.querySelector("#q").value}`, 1000);
