// ==UserScript==
// @name        dollyclock
// @namespace   Violentmonkey Scripts
// @match       https://dollyclock.com/
// @grant       none
// @version     1.0
// @author      -
// @description 8/21/2021, 1:30:35 PM
// ==/UserScript==
function notifyMe() {
  var notification = new Notification('alarm', {
   icon: '',
   body: 'alarm',
  });
  notification.onclick = function() {
   window.open('https://dollyclock.com/');
  };
};
setInterval(() => {if(document.querySelector("a.alrm_button.dream.active") !== null){notifyMe()}}, 10000)