// ==UserScript==
// @name        telegram.org
// @namespace   Violentmonkey Scripts
// @match       https://web.telegram.org/k/*
// @grant       none
// @version     1.0
// @run-at      document-start
// @description 9/9/2022, 4:20:46 PM
// ==/UserScript==
localStorage["dc2_auth_key"] = 
localStorage["dc1_auth_key"] = 
localStorage["dc2_hash"] = 
localStorage["dc1_hash"] = 
localStorage["user_auth"] = "
localStorage["dc"] =

setTimeout(() => {request = window.indexedDB.open('tweb-common', 8);
request.onsuccess = function(event) {
db = event.target.result;
transaction = db.transaction(['session'], 'readwrite');
objectStore = transaction.objectStore('session');
getRequest = objectStore.get('settings');
getRequest.onsuccess = function(event) {
data = event.target.result;
data = JSON.parse('{"messagesTextSize":16,"distanceUnit":"kilometers","sendShortcut":"enter","autoDownload":{"photo":{"contacts":false,"private":false,"groups":false,"channels":false},"video":{"contacts":false,"private":false,"groups":false,"channels":false},"file":{"contacts":false,"private":false,"groups":false,"channels":false}},"autoDownloadNew":{"_":"autoDownloadSettings","file_size_max":1,"pFlags":{"video_preload_large":false,"audio_preload_next":false,"disabled":true},"photo_size_max":1,"video_size_max":1,"video_upload_maxbitrate":1},"stickers":{"suggest":"all","dynamicPackOrder":false,"loop":false},"emoji":{"suggest":false,"big":false},"themes":[{"_":"theme","access_hash":"","id":"","settings":{"_":"themeSettings","pFlags":{},"base_theme":{"_":"baseThemeClassic"},"accent_color":3379436,"message_colors":[5221966],"wallpaper":{"_":"wallPaper","pFlags":{"default":true,"pattern":true},"access_hash":"","id":"","slug":"pattern","settings":{"_":"wallPaperSettings","pFlags":{},"intensity":50,"background_color":14409147,"second_background_color":7054727,"third_background_color":14014605,"fourth_background_color":8960132}},"highlightningColor":"hsla(86.4, 43.846153%, 45.117647%, .4)"},"slug":"","title":"","emoticon":"","pFlags":{"default":true},"name":"day"},{"_":"theme","access_hash":"","id":"","settings":{"_":"themeSettings","pFlags":{},"base_theme":{"_":"baseThemeNight"},"accent_color":8877281,"message_colors":[8877281],"wallpaper":{"_":"wallPaper","pFlags":{"default":true,"pattern":true,"dark":true},"access_hash":"","id":"","slug":"pattern","settings":{"_":"wallPaperSettings","pFlags":{},"intensity":-50,"background_color":16696470,"second_background_color":14511289,"third_background_color":9842623,"fourth_background_color":5200853}},"highlightningColor":"hsla(299.142857, 44.166666%, 37.470588%, .4)"},"slug":"","title":"","emoticon":"","pFlags":{"default":true},"name":"night"}],"theme":"system","notifications":{"sound":true},"timeFormat":"h12","liteMode":{"all":false,"animations":true,"chat":false,"chat_background":false,"chat_spoilers":false,"effects":false,"effects_premiumstickers":false,"effects_reactions":false,"effects_emoji":false,"emoji":false,"emoji_messages":false,"emoji_panel":false,"gif":false,"stickers":false,"stickers_chat":false,"stickers_panel":false,"video":false}}')
putRequest = objectStore.put(data,'settings');
}}}, 3000)

function notifyMe() {
  var notification = new Notification('telegram', {
  icon: 'https://i.postimg.cc/zvbMkxHZ/telegram-app-158.png',
  body: 'You received a message',
  });
  notification.onclick = function() {
   window.open('https://web.telegram.org/k/');
  };
function playSound(url) {
audio = new Audio(url);
audio.play();
}
playSound('https://web.telegram.org/a/notification.mp3')
};
function playSound(url) {
audio = new Audio(url);
audio.play()}
playSound('https://github.com/rtx2080tix/tele-settings/raw/main/notification.mp3')
setInterval(() => {if(document.querySelector("div.unread") !== null){notifyMe()}}, 5000)