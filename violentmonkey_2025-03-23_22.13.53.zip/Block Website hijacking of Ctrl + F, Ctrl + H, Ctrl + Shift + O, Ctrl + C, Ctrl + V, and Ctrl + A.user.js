// ==UserScript==
// @name         Block Website hijacking of Ctrl + F, Ctrl + H, Ctrl + Shift + O, Ctrl + C, Ctrl + V, and Ctrl + A
// @version      0.1
// @description  Prevent the website from hijacking Ctrl + F, Ctrl + H, Ctrl + Shift + O, Ctrl + C, Ctrl + V, and Ctrl + A while allowing their default actions
// @author       You
// @run-at       document-end
// @match        https://mapgenie.io/*
// @match        https://duckduckgo.com/*
// ==/UserScript==

(function() {
    // Function to override keyboard event listeners
    function overrideKeyboardEvents() {
        function stopEvent(e) {
            // Check if Ctrl key is pressed
            if (e.ctrlKey) {
                // Allow Ctrl + F
                if (e.key === 'f') {
                    e.stopImmediatePropagation(); // Prevent the website from detecting the key press
                    return; // Allow the browser's find dialog to open
                }
                // Allow Ctrl + H
                if (e.key === 'h') {
                    e.stopImmediatePropagation(); // Prevent the website from detecting the key press
                    return; // Allow the browser's history to open
                }
                // Allow Ctrl + Shift + O
                if (e.shiftKey && e.key === 'O') {
                    e.stopImmediatePropagation(); // Prevent the website from detecting the key press
                    return; // Allow the browser's bookmarks to open
                }
                // Allow Ctrl + C
                if (e.key === 'c') {
                    e.stopImmediatePropagation(); // Prevent the website from detecting the key press
                    return; // Allow the copy action
                }
                // Allow Ctrl + V
                if (e.key === 'v') {
                    e.stopImmediatePropagation(); // Prevent the website from detecting the key press
                    return; // Allow the paste action
                }
                // Allow Ctrl + A
                if (e.key === 'a') {
                    e.stopImmediatePropagation(); // Prevent the website from detecting the key press
                    return; // Allow the select all action
                }
            }

            // Block other combinations or individual key presses
            if (e.ctrlKey || e.shiftKey || e.altKey) {
                e.stopImmediatePropagation();
                e.preventDefault(); // Prevent default action for any other combination
            }
        }

        // Add event listeners for keyboard events
        document.addEventListener('keydown', stopEvent, true);
    }

    // Run the function to override events
    overrideKeyboardEvents();
})();