// ==UserScript==
// @name        thdisc.com
// @namespace   Violentmonkey Scripts
// @match       https://down.thdisc.com/TLMC_beyond/*
// @grant       none
// @version     1.0
// @author      -
// @description 6/28/2023, 12:34:46 PM
// ==/UserScript==
setTimeout(() => document.querySelector("#tree").remove(), 1000);