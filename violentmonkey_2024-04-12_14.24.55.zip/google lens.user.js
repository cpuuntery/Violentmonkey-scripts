// ==UserScript==
// @name        google lens
// @namespace   Violentmonkey Scripts
// @match       https://lens.google.com/*
// @grant       none
// @version     1.0
// @author      -
// @description 5/2/2023, 9:22:55 AM
// ==/UserScript==
setInterval(() => document.querySelectorAll(".I9m2Y").forEach(x => {if (x.style.fontSize.match(/\d+/gm)[0] < 11){x.style.fontSize = '11px'}}), 1000);

setInterval(() => {
    var treeWalker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (treeWalker.nextNode()) {
        var node = treeWalker.currentNode;
        node.nodeValue = node.nodeValue.replace(/picture/gi, 'what');
        node.nodeValue = node.nodeValue.replace(/teeth/gi, 'what');
        node.nodeValue = node.nodeValue.replace(/chichi/gi, 'papa');
        node.nodeValue = node.nodeValue.replace(/haha/gi, 'mama');
    }
}, 1500);
