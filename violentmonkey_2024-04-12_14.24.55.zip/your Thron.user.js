// ==UserScript==
// @name        your Thron
// @namespace   Violentmonkey Scripts
// @match       file:///C:/Users/Yousif/Videos/your*
// @grant       none
// @version     1.0
// @author      -
// @description 11/16/2020, 7:51:21 AM
// ==/UserScript==
var regex = prompt('Enter the json file here. But before that did you change the cookie');
var regex1 = regex.replace(/(?<=[1-9]\d*,)"url.*?\//g, '"url": "https://prowebtoon-phinf.pstatic.net/');
var regex2 = regex1.replace(/\?type=q70/g,'');
var data = JSON.parse(regex2);
data["message"]["result"]["episodeInfo"]["imageInfo"].forEach(function(obj) {
  var img = new Image();
  img.src = obj.url;
  document.getElementById("img-container").appendChild(img);
});