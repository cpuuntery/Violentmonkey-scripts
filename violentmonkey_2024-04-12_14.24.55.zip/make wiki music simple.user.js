// ==UserScript==
// @name        make wiki music simple
// @namespace   Violentmonkey Scripts
// @match       https://en.touhouwiki.net/*
// @grant       none
// @version     1.0
// @author      -
// @description 8/5/2020, 10:46:44 PM
// @run-at      document-end
// ==/UserScript==
function exc() {
let change = document.querySelectorAll('span[style="border-bottom: 1px dotted;"]')
for(let i=0; i<change.length; i++){
change[i].innerText = change[i].title}
}
setTimeout(exc, 1000);
