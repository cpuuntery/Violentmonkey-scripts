// ==UserScript==
// @name        pixiv some popular images with search
// @namespace   Violentmonkey Scripts
// @match       https://www.pixiv.net/en/tags/*
// @grant       none
// @version     1.0
// @author      -
// @description 5/3/2023, 1:44:41 PM
// ==/UserScript==
setInterval(() => {
    if (!(document.querySelector("ul.sc-l7cibp-1.krFoBL li div div div") == document.querySelector("div.sc-rp5asc-0.eGQovZ"))) {

        document.querySelectorAll("li.sc-jn70pf-4.chUwBg").forEach(x => document.querySelector("ul.sc-l7cibp-1.krFoBL").prepend(x))

    }
}, 1000)
