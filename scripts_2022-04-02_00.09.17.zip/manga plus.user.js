// ==UserScript==
// @name        manga plus
// @namespace   Violentmonkey Scripts
// @match       https://mangaplus.shueisha.co.jp/*
// @grant       none
// @version     1.0
// @author      -
// @description 4/5/2021, 11:19:26 PM
// ==/UserScript==
localStorage["quarity"] = "super_high"