// ==UserScript==
// @name        donmai.us
// @namespace   Violentmonkey Scripts
// @match       https://safebooru.donmai.us/*
// @grant       none
// @version     1.0
// @author      -
// @description 7/3/2021, 6:59:39 PM
// ==/UserScript==
$('[data-tags~="spoilers"]').remove()
$('[data-tags~="guro"]').remove()
$('[data-tags~="scat"]').remove()
$('[data-tags~="bikini"]').remove()
$('[data-tags~="swimsuit"]').remove()
$('[data-tags~="bra"]').remove()
$('[data-tags~="animal_ears"]').remove()
$('[data-tags~="panties"]').remove()
$('[data-tags~="spread_legs"]').remove()
$('[data-tags~="standing_split"]').remove()
$('[data-tags~="ass"]').remove()
$('[data-tags~="yuri"]').remove()
$('[data-tags~="large_breasts"]').remove()
$('[data-tags~="bennett_(genshin_impact)"]').remove()
$('[data-tags~="pocky"]').remove()
$('[data-tags~="leg_up"]').remove()
$('[data-tags~="ass_visible_through_thighs"]').remove()
$('[data-tags~="cameltoe"]').remove()
$('[data-tags~="center_opening"]').remove()
$('[data-tags~="feet"]').remove()
$('[data-tags~="tongue"]').remove()
$('[data-tags~="tongue_out"]').remove()
$('[data-tags~="knees_up"]').remove()
$('[data-tags~="tail"]').remove()
$('[data-tags~="christmas"]').remove()
$('[data-tags~="revealing_clothes"]').remove()
$('[data-tags~="navel"]').remove()
$('[data-tags~="cleavage"]').remove()
$('[data-tags~="sweat"]').remove()
$('[data-tags~="heavy_breathing"]').remove()
$('[data-tags~="torn_clothes"]').remove()
$('[data-tags~="ganyu_(genshin_impact)"]').remove()
$('[data-tags~="bdsm"]').remove()
$('[data-tags~="alternate_costume"]').remove()
$('[data-tags~="mona_(genshin_impact)"]').remove()
$('[data-tags~="adapted_costume"]').remove()
$('[data-tags~="school_uniform"]').remove()
$('[data-tags~="fischl_(genshin_impact)_(cosplay)"]').remove()
$('[data-tags~="cosplay"]').remove()
$('[data-file-ext="mp4"]').remove()


