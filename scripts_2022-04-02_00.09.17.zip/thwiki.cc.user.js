// ==UserScript==
// @name        thwiki.cc
// @namespace   Violentmonkey Scripts
// @match       https://thwiki.cc/*
// @grant       none
// @version     1.0
// @author      -
// @description 8/15/2020, 1:25:15 PM
// ==/UserScript==
document.querySelector("body").className = "mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-0 ns-subject page-協奏符「幻湊響」 rootpage-協奏符「幻湊響」 skin-unicorn action-view unicorn-animateLayout hide-searchpage hide-sidebar scrolled-down"