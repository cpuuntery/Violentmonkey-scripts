// ==UserScript==
// @name        New script - fc2.com
// @namespace   Violentmonkey Scripts
// @match       http://iruka33.web.fc2.com/*
// @grant       none
// @version     1.0
// @author      -
// @description 2/21/2021, 6:54:47 AM
// @require http://code.jquery.com/jquery-3.5.1.slim.min.js
// ==/UserScript==
let elm = document.createElement('textarea');
elm.setAttribute("id", "output");
document.querySelector('body').prepend(elm)
var data = $('#output').text();
$("td a:contains('mid')").each(function() {data += this.href + '\n'});
$('#output').text( data );