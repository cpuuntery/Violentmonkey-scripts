// ==UserScript==
// @name        New script - stackoverflow.com
// @namespace   Violentmonkey Scripts
// @match       https://stac*.com/*
// @grant       none
// @version     1.0
// @author      -
// @description 10/15/2021, 1:00:44 AM
// ==/UserScript==
localStorage["OptanonAlertBoxClosed"] = "2021-10-14T21:59:29.956Z"