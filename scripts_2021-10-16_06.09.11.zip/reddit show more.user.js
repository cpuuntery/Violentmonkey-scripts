// ==UserScript==
// @name        reddit show more
// @namespace   Violentmonkey Scripts
// @match       https://www.reddit.com/*
// @grant       none
// @version     1.0
// @author      -
// @description 8/21/2020, 3:21:47 AM
// @require https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js
// ==/UserScript==
function exc() {
if ($("#CommentSort--SortPicker:contains('best')").length == 1){
document.querySelector("button#CommentSort--SortPicker").click()
$("._2-cXnP74241WI7fpcpfPmg:contains('top')").click()
}}
setTimeout(exc, 3000);